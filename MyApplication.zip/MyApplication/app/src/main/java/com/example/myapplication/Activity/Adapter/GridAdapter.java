package com.example.myapplication.Activity.Adapter;

import android.content.Context;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.myapplication.Activity.Model.User;
import com.example.myapplication.R;

import java.util.ArrayList;

public class GridAdapter extends BaseAdapter {
 private Context context;
 private LayoutInflater layoutInflater;
 private ArrayList<User> uyeler;

    public GridAdapter() {
    }

    public GridAdapter(Context context, ArrayList<User> uyeler) {
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.uyeler = uyeler;
    }

    @Override
    public int getCount() {
        return uyeler.size();
    }

    @Override
    public Object getItem(int position) {
        return uyeler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v= layoutInflater.inflate(R.layout.uyesatirgoruntusu,null);

        TextView tvAdSoyad = v.findViewById(R.id.tvAdSoyad);
        TextView tvMail= v.findViewById(R.id.tvMailAdresi);

        String adSoyad =uyeler.get(position).getAd()+ " "+uyeler.get(position).getSoyad();
        tvAdSoyad.setText(adSoyad);

        tvMail.setText(uyeler.get(position).getEmail());

        return v ;
    }
}
