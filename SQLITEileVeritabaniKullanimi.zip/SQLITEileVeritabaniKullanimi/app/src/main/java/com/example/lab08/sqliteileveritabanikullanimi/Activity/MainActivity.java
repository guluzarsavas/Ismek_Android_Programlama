package com.example.lab08.sqliteileveritabanikullanimi.Activity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.lab08.sqliteileveritabanikullanimi.R;

public class MainActivity extends AppCompatActivity {

    EditText etMail, etAdSoyad, etDogumYili;
    Button btnEkle;


    EditText etUyeID;
    Button btnListele, btnGuncelle,btnSil;

    LinearLayout linearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StringBuilder sb= new StringBuilder();
        sb.append("CREATE TABLE IF NOT EXISTS Uyeler");//TABLO ÜRET UYELER ADINDA//if not exists ekleyerek "eğer böyle bir tablo yoksa ekle" demiş olduk. yoksa uygulama ikinci kez açıldığında hata verirdi"
        sb.append("(");
        sb.append("id INTEGER PRIMARY KEY AUTOINCREMENT,");//KOLONLAR BUNLAR
        sb.append("adsoyad TEXT,");
        sb.append("email TEXT,");
        sb.append("dogum_yili INTEGER");
        sb.append(")");



        tabloUret("mydb",sb.toString());

        etAdSoyad=findViewById(R.id.etAdSoyad);
        etDogumYili=findViewById(R.id.etDogumYili);
        etMail=findViewById(R.id.etMail);
        btnEkle=findViewById(R.id.btnEkle);

        etUyeID=findViewById(R.id.etUyeID);
        btnSil=findViewById(R.id.btnSil);
        btnGuncelle=findViewById(R.id.btnGuncelle);
        btnListele=findViewById(R.id.btnListele);
        linearLayout=findViewById(R.id.linearLayout);


        btnEkle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uyeEkle(
                        "mydb",
                        etAdSoyad.getText().toString(),
                        etMail.getText().toString(),
                        Integer.parseInt(etDogumYili.getText().toString())
                );
            }
        });

        btnListele.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uyeListele("mydb","Uyeler");
            }
        });
        btnGuncelle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        btnSil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uyeSil("mydb",Integer.parseInt(etUyeID.getText().toString()));
            }
        });
    }

    public void tabloUret(String dbName,String sorgu){

        SQLiteDatabase db = openOrCreateDatabase(dbName, MODE_PRIVATE, null);
        db.execSQL(sorgu);
        /*
          db.execSQL("Create Table if not exists Uyeler (id INTEGER PRIMARY KEY, Name varchar, Surname varchar, Age int(3));");
        */
    }






    public void uyeEkle(String dbName, String uyeAdi, String uyeSoyadi, int uyeYas){
        SQLiteDatabase db = openOrCreateDatabase(dbName, MODE_PRIVATE, null);

        db.execSQL("insert into Uyeler values(NULL,'"+uyeAdi+"','"+uyeSoyadi+"',"+uyeYas+")");
    }

    public void uyeGuncelle(String dbName,int userId,String uyeAdi,String uyeSoyadi){
        SQLiteDatabase db = openOrCreateDatabase(dbName, MODE_PRIVATE, null);
        db.execSQL("update Uyeler SET Name='"+uyeAdi+"',Surname='"+uyeSoyadi+"' where id='"+userId+"'");
    }
    public  void uyeSil(String dbName,int userId){
        SQLiteDatabase db = openOrCreateDatabase(dbName, MODE_PRIVATE, null);
        db.execSQL("delete from Uyeler where id='"+userId+"'");
    }
    public void uyeListele(String dbName, String tableName){
        SQLiteDatabase db = openOrCreateDatabase(dbName, MODE_PRIVATE, null);
        Cursor c = db.rawQuery("Select * from '"+tableName+"'",null);
        c.moveToFirst();
        StringBuilder bld= new StringBuilder("");
        do{
            TextView tv =new TextView(getApplicationContext());
            tv.setText(c.getString(c.getColumnIndex("adsoyad")));
            linearLayout.addView(tv);

          //  bld.append(c.getString(0) +" "+ c.getString(1) + " "+c.getInt(2) +"");


        }while(c.moveToNext());


    }
}
