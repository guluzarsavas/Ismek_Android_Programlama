package com.example.lab08.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.example.lab08.ilanlaruygulamasi.R;

public class IlanActivity extends AppCompatActivity {
 ListView listViewIlanlar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ilan);
        listViewIlanlar=findViewById(R.id.listViewIlanlar);

    }
}
