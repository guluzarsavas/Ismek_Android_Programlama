package com.example.lab08.Model;

public class Ulke {
    private int ulkeKodu;
    private String bayrak;
    private String ad;
    private String baskent;
    private String paraBirim;
    private String internetCode;
    private String resmiDil;
    private double yuzOlcumu;

    public Ulke() {
    }

    public Ulke(int ulkeKodu, String bayrak, String ad, String baskent, String paraBirim,
                String internetCode, String resmiDil, double yuzOlcumu) {
        this.ulkeKodu = ulkeKodu;
        this.bayrak = bayrak;
        this.ad = ad;
        this.baskent = baskent;
        this.paraBirim = paraBirim;
        this.internetCode = internetCode;
        this.resmiDil = resmiDil;
        this.yuzOlcumu = yuzOlcumu;
    }

    public int getUlkeKodu() {
        return ulkeKodu;
    }

    public void setUlkeKodu(int ulkeKodu) {
        this.ulkeKodu = ulkeKodu;
    }

    public String getBayrak() {
        return bayrak;
    }

    public void setBayrak(String bayrak) {
        this.bayrak = bayrak;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getBaskent() {
        return baskent;
    }

    public void setBaskent(String baskent) {
        this.baskent = baskent;
    }

    public String getParaBirim() {
        return paraBirim;
    }

    public void setParaBirim(String paraBirim) {
        this.paraBirim = paraBirim;
    }

    public String getInternetCode() {
        return internetCode;
    }

    public void setInternetCode(String internetCode) {
        this.internetCode = internetCode;
    }

    public String getResmiDil() {
        return resmiDil;
    }

    public void setResmiDil(String resmiDil) {
        this.resmiDil = resmiDil;
    }

    public double getYuzOlcumu() {
        return yuzOlcumu;
    }

    public void setYuzOlcumu(double yuzOlcumu) {
        this.yuzOlcumu = yuzOlcumu;
    }
}
