package com.example.lab08.Model;

public class Sehir {
    private int ulkeKodu;
    private String ad;
    private String plakaKodu;
    private int alanKodu;
    private int nufus;

    public Sehir() {
    }

    public Sehir(int ulkeKodu, String ad, String plakaKodu, int alanKodu, int nufus) {
        this.ulkeKodu = ulkeKodu;
        this.ad = ad;
        this.plakaKodu = plakaKodu;
        this.alanKodu = alanKodu;
        this.nufus = nufus;
    }

    public int getUlkeKodu() {
        return ulkeKodu;
    }

    public void setUlkeKodu(int ulkeKodu) {
        this.ulkeKodu = ulkeKodu;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getPlakaKodu() {
        return plakaKodu;
    }

    public void setPlakaKodu(String plakaKodu) {
        this.plakaKodu = plakaKodu;
    }

    public int getAlanKodu() {
        return alanKodu;
    }

    public void setAlanKodu(int alanKodu) {
        this.alanKodu = alanKodu;
    }

    public int getNufus() {
        return nufus;
    }

    public void setNufus(int nufus) {
        this.nufus = nufus;
    }
}
