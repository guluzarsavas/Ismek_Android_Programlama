package com.example.lab08.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.lab08.Model.Ulke;
import com.example.lab08.ilanlaruygulamasi.R;

import java.util.ArrayList;

public class AdapterSpinnerUlke extends BaseAdapter {
    private LayoutInflater layoutInflater;
    private Context context;
    private ArrayList<Ulke> ulkeler;

    public AdapterSpinnerUlke() {
    }

    public AdapterSpinnerUlke(Context context, ArrayList<Ulke> ulkeler) {
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.context = context;
        this.ulkeler = ulkeler;
    }

    @Override
    public int getCount() {
        return ulkeler.size();
    }

    @Override
    public Object getItem(int position) {
        return ulkeler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v=layoutInflater.inflate(R.layout.spinner_satirgoruntusu,null);
        ImageView ivUlke=v.findViewById(R.id.ivspinnerBayrak);
        TextView tvIsim=v.findViewById(R.id.tvUlke);
        tvIsim.setText(ulkeler.get(position).getAd());

        Glide.with(context).load(ulkeler.get(position).getBayrak()).into(ivUlke);

        return v;

    }
}
