package com.example.lab08.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Spinner;

import com.example.lab08.Adapter.AdapterListSehir;
import com.example.lab08.Adapter.AdapterSpinnerUlke;
import com.example.lab08.Model.Sehir;
import com.example.lab08.Model.Ulke;
import com.example.lab08.ilanlaruygulamasi.R;

import java.util.ArrayList;

public class SehirActivity extends AppCompatActivity {
    Spinner spinnerUlkeler;
    ListView listViewSehirler;

    AdapterListSehir adapterListSehirlistSehir;
    AdapterSpinnerUlke adapterSpinnerUlkespinnerUlke;

    ArrayList<Sehir> sehirler = new ArrayList<>();
    ArrayList<Ulke> ulkeler = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sehir);

        listViewSehirler = findViewById(R.id.listViewSehirler);
        spinnerUlkeler = findViewById(R.id.spinnerUlkeler);




 /*
 int ulkeKodu, String bayrak, String ad, String baskent, String paraBirim,
                String internetCode, String resmiDil, double yuzOlcumu
  */
        ulkeler.add(new Ulke(

                90,
                "https://yunti.files.wordpress.com/2013/04/turkiye-wallpaper-zeklimekan.jpg",
                "Türkiye Cumhuriyeti",
                "Ankara",
                "TL",
                ".tr",
                "Türkçe",
                783.562



        ));
        ulkeler.add(new Ulke(

                44,
                "http://bayrakevi.com/image/cache/data/devlet1/ingiliz-800x800.jpg",
                "İngiltere ",
                "Londra",
                "Sterlin",
                ".uk",
                "İngilizce",
                130.395



        ));
        ulkeler.add(new Ulke(

                34,
                "https://st.depositphotos.com/1503367/3041/i/950/depositphotos_30415299-stock-photo-wavy-flag-of-spain.jpg",
                "İspanya",
                "Ankara",
                "TL",
                ".tr",
                "Türkçe",
                783.562



        ));









        adapterListSehirlistSehir = new AdapterListSehir(getApplicationContext(), sehirler);
        adapterSpinnerUlkespinnerUlke = new AdapterSpinnerUlke(getApplicationContext(), ulkeler);

        spinnerUlkeler.setAdapter(adapterSpinnerUlkespinnerUlke);
        listViewSehirler.setAdapter(adapterListSehirlistSehir);

        spinnerUlkeler.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (ulkeler.get(position).getUlkeKodu() == 90) {
                    sehirler.add(new Sehir(

                            90, "Ankara", "06", 0, 0
                    ));

                    sehirler.add(new Sehir(

                            90, "İstanbul", "34", 0, 0
                    ));


                }else if(ulkeler.get(position).getUlkeKodu()==34){

                    sehirler.add(new Sehir(

                            34, "Barcelona", "", 0, 0
                    ));
                    sehirler.add(new Sehir(

                            34, "Madrid", "", 0, 0
                    ));
                }else if(ulkeler.get(position).getUlkeKodu()==44){

                    sehirler.add(new Sehir(

                            44, "Londra", "", 0, 0
                    ));

                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
}
