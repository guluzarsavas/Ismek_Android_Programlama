package com.example.lab08.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.lab08.Model.Sehir;
import com.example.lab08.ilanlaruygulamasi.R;

import java.util.ArrayList;

public class AdapterListSehir extends BaseAdapter {
    private LayoutInflater layoutInflater;
    private Context context;
    private ArrayList<Sehir>arrayList;

    public AdapterListSehir() {
    }

    public AdapterListSehir( Context context, ArrayList<Sehir> arrayList) {
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.context = context;
        this.arrayList = arrayList;
    }

    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return arrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v=layoutInflater.inflate(R.layout.sehirler_satirgoruntusu,null);

        TextView tvBaslik , tvPlaka , tvNufus;

        tvBaslik=v.findViewById(R.id.tvSehirAdi);
        tvPlaka=v.findViewById(R.id.tvPlaka);
        tvNufus=v.findViewById(R.id.tvSehirNufus);

        tvBaslik.setText(arrayList.get(position).getAd());
        tvPlaka.setText(arrayList.get(position).getPlakaKodu());
        tvNufus.setText(""+arrayList.get(position).getNufus());

        return v;
    }
}
