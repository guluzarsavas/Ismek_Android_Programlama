package com.example.lab08.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.lab08.ilanlaruygulamasi.R;

public class IlanDetayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ilan_detay);
    }
}
