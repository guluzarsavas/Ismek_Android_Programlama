package com.example.lab08.baseadapterkullanimi.Model;

public class Markalar {
    private int id;
    private String ad;
    private String logo;
    private int kurulusYili;
    private String ulke;
    //her bir field için get set metodu zorunludur.kapsülleme.


    public Markalar() {
        //boş constructor için sağ tık, Generate, constructor,select none
    }

    public Markalar(int id, String ad, String logo, int kurulusYili, String ulke) {
        this.id = id;
        this.ad = ad;
        this.logo = logo;
        this.kurulusYili = kurulusYili;
        this.ulke = ulke;
        //dolu seçim için sağ tık, Generate, constructor, hepsini seç, ok
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public int getKurulusYili() {
        return kurulusYili;
    }

    public void setKurulusYili(int kurulusYili) {
        this.kurulusYili = kurulusYili;
    }

    public String getUlke() {
        return ulke;
    }

    public void setUlke(String ulke) {
        this.ulke = ulke;
    }

}
