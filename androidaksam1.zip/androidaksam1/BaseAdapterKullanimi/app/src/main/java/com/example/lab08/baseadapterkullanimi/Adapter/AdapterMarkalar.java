package com.example.lab08.baseadapterkullanimi.Adapter;

import android.content.Context;
import android.media.Image;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.lab08.baseadapterkullanimi.Model.Markalar;
import com.example.lab08.baseadapterkullanimi.R;

import java.util.ArrayList;

public class AdapterMarkalar  extends BaseAdapter{
    private ArrayList<Markalar>markalar;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterMarkalar() {
    }

    public AdapterMarkalar(ArrayList<Markalar> markalar, Context context) {
        this.markalar = markalar;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        //listenin eleman sayısını döndürür
        return markalar.size();
    }

    @Override
    public Object getItem(int position) {
        //get item, liste elemanını döndürür
        return markalar.get(position);
    }

    @Override
    public long getItemId(int position) {
        //liste elemanının sırasını döndürür
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //get view, liste elemaının satır görüntüsünü döndürür.
        //getview ilw liste elemanın satır görüntüsü için yeni bir layout üreteceğiz. yeni bir view
       View v=layoutInflater.inflate(R.layout.markalar_satirgoruntusu,null);
       //inflate:baglayıcı
        //layoutinflater: bir satırın layouta baglanması görevini gorur.
        TextView tvMarkaAdi =v.findViewById(R.id.textView);
        TextView tvKurulusYili =v.findViewById(R.id.tvkurulus);
        TextView tvUlke=v.findViewById(R.id.tvulke);
        ImageView ivlogo=v.findViewById(R.id.ivLogo);
        Glide.with(context).load(markalar.get(position).getLogo()).into(ivlogo);

        tvMarkaAdi.setText(""+markalar.get(position).getAd());
        tvKurulusYili.setText(""+markalar.get(position).getKurulusYili());
        tvUlke.setText(markalar.get(position).getUlke());

        return v;
    }
}
