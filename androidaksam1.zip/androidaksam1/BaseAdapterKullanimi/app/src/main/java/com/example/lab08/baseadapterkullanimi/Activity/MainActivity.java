package com.example.lab08.baseadapterkullanimi.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.lab08.baseadapterkullanimi.Adapter.AdapterMarkalar;
import com.example.lab08.baseadapterkullanimi.Model.Markalar;
import com.example.lab08.baseadapterkullanimi.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
  ListView listview;
  ArrayList<Markalar>markalar=new ArrayList<>();
  AdapterMarkalar adapterMarkalar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listview=findViewById(R.id.listview);

        markalar.add( new Markalar(1,"mercedes","http://www.carlogos.org/logo/Mercedes-Benz-logo-2011-1920x1080.png",1999,"almanya"));
        markalar.add( new Markalar(1,"mercedes","http://www.carlogos.org/logo/Mercedes-Benz-logo-2011-1920x1080.png",1999,"almanya"));
        markalar.add( new Markalar(1,"mercedes","http://www.carlogos.org/logo/Mercedes-Benz-logo-2011-1920x1080.png",1999,"almanya"));
        markalar.add( new Markalar(1,"mercedes","http://www.carlogos.org/logo/Mercedes-Benz-logo-2011-1920x1080.png",1999,"almanya"));
        markalar.add( new Markalar(1,"mercedes","http://www.carlogos.org/logo/Mercedes-Benz-logo-2011-1920x1080.png",1999,"almanya"));
        markalar.add( new Markalar(1,"mercedes","http://www.carlogos.org/logo/Mercedes-Benz-logo-2011-1920x1080.png",1999,"almanya"));
        markalar.add( new Markalar(1,"mercedes","http://www.carlogos.org/logo/Mercedes-Benz-logo-2011-1920x1080.png",1999,"almanya"));
        markalar.add( new Markalar(1,"mercedes","http://www.carlogos.org/logo/Mercedes-Benz-logo-2011-1920x1080.png",1999,"almanya"));
        markalar.add( new Markalar(1,"mercedes","http://www.carlogos.org/logo/Mercedes-Benz-logo-2011-1920x1080.png",1999,"almanya"));
        markalar.add( new Markalar(1,"mercedes","http://www.carlogos.org/logo/Mercedes-Benz-logo-2011-1920x1080.png",1999,"almanya"));
        markalar.add( new Markalar(1,"mercedes","http://www.carlogos.org/logo/Mercedes-Benz-logo-2011-1920x1080.png",1999,"almanya"));
        markalar.add( new Markalar(1,"mercedes","http://www.carlogos.org/logo/Mercedes-Benz-logo-2011-1920x1080.png",1999,"almanya"));
        markalar.add( new Markalar(1,"mercedes","http://www.carlogos.org/logo/Mercedes-Benz-logo-2011-1920x1080.png",1999,"almanya"));
        markalar.add( new Markalar(1,"mercedes","http://www.carlogos.org/logo/Mercedes-Benz-logo-2011-1920x1080.png",1999,"almanya"));
        markalar.add( new Markalar(1,"mercedes","http://www.carlogos.org/logo/Mercedes-Benz-logo-2011-1920x1080.png",1999,"almanya"));
        markalar.add( new Markalar(1,"mercedes","http://www.carlogos.org/logo/Mercedes-Benz-logo-2011-1920x1080.png",1999,"almanya"));






        adapterMarkalar=new AdapterMarkalar(markalar,getApplicationContext());
        listview.setAdapter(adapterMarkalar);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(
                        getApplicationContext(),
                        markalar.get(position).getAd(),
                        Toast.LENGTH_LONG

                ).show();
            }
        });
    }
}
