package com.example.lab08.baseadapterkullanimi.Model;

public class Modeller {

    private String isim;
    private String resim;
    private String kasaTipi;
    private String motorGucu;
    private String vitesTipi;
    private String [] renkler;
    private String yakitTuru;
    private int kapiSayisi;
    private int beygirGucu;


    public Modeller() {
    }

    public Modeller(String isim, String resim, String kasaTipi, String motorGucu,
                    String vitesTipi, String[] renkler, String yakitTuru, int kapiSayisi, int beygirGucu) {
        this.isim = isim;
        this.resim = resim;
        this.kasaTipi = kasaTipi;
        this.motorGucu = motorGucu;
        this.vitesTipi = vitesTipi;
        this.renkler = renkler;
        this.yakitTuru = yakitTuru;
        this.kapiSayisi = kapiSayisi;
        this.beygirGucu = beygirGucu;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }

    public String getKasaTipi() {
        return kasaTipi;
    }

    public void setKasaTipi(String kasaTipi) {
        this.kasaTipi = kasaTipi;
    }

    public String getMotorGucu() {
        return motorGucu;
    }

    public void setMotorGucu(String motorGucu) {
        this.motorGucu = motorGucu;
    }

    public String getVitesTipi() {
        return vitesTipi;
    }

    public void setVitesTipi(String vitesTipi) {
        this.vitesTipi = vitesTipi;
    }

    public String[] getRenkler() {
        return renkler;
    }

    public void setRenkler(String[] renkler) {
        this.renkler = renkler;
    }

    public String getYakitTuru() {
        return yakitTuru;
    }

    public void setYakitTuru(String yakitTuru) {
        this.yakitTuru = yakitTuru;
    }

    public int getKapiSayisi() {
        return kapiSayisi;
    }

    public void setKapiSayisi(int kapiSayisi) {
        this.kapiSayisi = kapiSayisi;
    }

    public int getBeygirGucu() {
        return beygirGucu;
    }

    public void setBeygirGucu(int beygirGucu) {
        this.beygirGucu = beygirGucu;
    }
}
