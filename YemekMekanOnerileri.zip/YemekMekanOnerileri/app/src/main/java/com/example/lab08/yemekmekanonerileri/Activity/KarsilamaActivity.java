package com.example.lab08.yemekmekanonerileri.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.lab08.yemekmekanonerileri.R;

public class KarsilamaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_karsilama);

        this.getSupportActionBar().hide();//toolbarı gizler
        //logoyu 3 saniye gösterelim.
        new Bekle().start();

    }



    private class Bekle extends Thread{
        @Override
        public void run() {
            super.run();
            try {
                Thread.sleep(5000);
            }catch (Exception e){}
            startActivity(new Intent(KarsilamaActivity.this,KategoriActivity.class));
            finish();
        }
    }


}
