package com.example.lab08.listview_arrayadapter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Sayfa2Activity extends AppCompatActivity {
  TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sayfa2);
        //bir önceki sayfadan gelen değeri yakalamak için
        String sehir= getIntent().getStringExtra("sehir");

        textView=findViewById(R.id.textView);
        textView.setText(sehir);
    }
}
