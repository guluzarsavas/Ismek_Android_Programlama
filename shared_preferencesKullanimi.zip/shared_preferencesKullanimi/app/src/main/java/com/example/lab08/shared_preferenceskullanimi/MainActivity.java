package com.example.lab08.shared_preferenceskullanimi;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

//intentten farkı uyg kapatılsa bile depoladığımız veri kalabilir
public class MainActivity extends AppCompatActivity {
    EditText etMesaj;
    Button btnGonder;
    SharedPreferences sp; //tanımlanmış değerleri çağırmak için
    SharedPreferences.Editor spe; // crud işlemleri için sp editor kullanılır.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        spe = sp.edit();
        etMesaj = findViewById(R.id.etMesaj);
        etMesaj.setText(sp.getString("mesaj",""));//2. sayfada daha önce girilen son veriyi gösterir
        btnGonder = findViewById(R.id.btnGonder);
        btnGonder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //sharedpreferences içine veri kaydedebilmek için put metodları kullandık.
                spe.putString("mesaj", etMesaj.getText().toString());
                spe.commit();//değişiklikleri kaydedebilmek için.

                startActivity( new Intent(getApplicationContext(),sayfa2.class));
            }
        });
    }
}
