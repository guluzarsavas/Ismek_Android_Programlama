package com.example.lab08.shared_preferenceskullanimi;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class sayfa2 extends AppCompatActivity {
   EditText etdeger;
   SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sayfa2);
        sp= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        etdeger=findViewById(R.id.etdeger);
        etdeger.setText(sp.getString("mesaj",""));
    }
}
