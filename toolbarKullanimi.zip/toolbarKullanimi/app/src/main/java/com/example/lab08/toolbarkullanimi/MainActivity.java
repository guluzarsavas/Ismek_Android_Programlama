package com.example.lab08.toolbarkullanimi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnGiris;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // this.setTitle("Anasayfa");//sayfa basliğini değişmek için
        //  setTitle("Anasayfa");//sayfa basliği deişme ikinci yol
        getSupportActionBar().setTitle("anasayfa");//3.yol
        getSupportActionBar().setSubtitle("Alt Başlık");
        //  getSupportActionBar().setDisplayHomeAsUpEnabled(true);//toolbara geri butonu eklenir

        btnGiris = findViewById(R.id.btnGiris);
        btnGiris.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), sayfa2.class);
                startActivity(i);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //menu main.xml menusunu main activity toolbarına bağladık yoksa görünmez
        getMenuInflater().inflate(R.menu.menu_main, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    //tıklanan menu ıtemın yakalanma olayı
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.id_favoriler) {
            Toast.makeText(getApplicationContext(),"favori sayfası",Toast.LENGTH_LONG).show();
        } else if (item.getItemId() == R.id.id_hakkimizda) {
            Toast.makeText(getApplicationContext(),"hakkımızda sayfası",Toast.LENGTH_LONG).show();
        } else if (item.getItemId() == R.id.id_iletisim) {
            Toast.makeText(getApplicationContext(),"iletisim sayfası",Toast.LENGTH_LONG).show();
        } else if (item.getItemId() == R.id.id_googleplay) {
            Toast.makeText(getApplicationContext(),"google play sayfası",Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }
}
