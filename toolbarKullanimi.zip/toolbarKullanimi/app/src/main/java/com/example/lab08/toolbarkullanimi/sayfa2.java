package com.example.lab08.toolbarkullanimi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

public class sayfa2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sayfa2);

        getSupportActionBar().setTitle("İkinci Sayfa");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);//toolbara geri butonu eklenir
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //geri butonunun tıklama olayı
        if(item.getItemId()==android.R.id.home){
            finish();

        }
        return super.onOptionsItemSelected(item);
    }
}
