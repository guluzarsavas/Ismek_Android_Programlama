package com.example.lab08.ornek2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class sayfa2 extends AppCompatActivity {
   EditText tvAdSoyad, tvyas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sayfa2);
        tvAdSoyad=findViewById(R.id.);

    }
}
