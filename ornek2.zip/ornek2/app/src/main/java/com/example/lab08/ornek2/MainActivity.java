package com.example.lab08.ornek2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
  EditText etad , etsoyad , etyas;
  Button btngonder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etad=findViewById(R.id.etad);
        etsoyad=findViewById(R.id.etsoyad);
        etyas=findViewById(R.id.etyas);
        btngonder=findViewById(R.id.btngonder);


        btngonder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Adsoyad=etad.getText().toString()+""+etsoyad.getText().toString();
                Intent intent= new Intent(MainActivity.this,sayfa2.class);
                intent.putExtra("yas",Integer.parseInt(etyas.getText().toString()));
                intent.putExtra("ad",etad.getText().toString()+etsoyad.getText().toString());
                startActivity(intent);

            }
        });

    }
}
