package com.example.lab08.autocomplete_textview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;

public class MainActivity extends AppCompatActivity {

    AutoCompleteTextView actv;
    MultiAutoCompleteTextView mactv;

    String[] sehirler={"kars", "kastamonu", "erzincan","erzurum","muğla","muş"};
    ArrayAdapter<String> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        actv =findViewById(R.id.autoCompleteTextView);
        mactv=findViewById(R.id.multiAutoCompleteTextView);
        adapter=new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_spinner_item,sehirler);
        actv.setAdapter(adapter);
        actv.setThreshold(2);//kaç karakterden sonra öneride bulunacağı

        mactv.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());//MultiAutoCompleteTextView çalışması için gerekli
        mactv.setAdapter(adapter);
    }
}
