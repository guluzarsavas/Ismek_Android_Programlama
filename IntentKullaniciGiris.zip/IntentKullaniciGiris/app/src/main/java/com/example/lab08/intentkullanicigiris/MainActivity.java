package com.example.lab08.intentkullanicigiris;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
  EditText etPassword, etKullanici;
  Button btnGiris;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etPassword=findViewById(R.id.etPassword);
        etKullanici=findViewById(R.id.etKullanici);
        btnGiris=findViewById(R.id.btnGiris);

        btnGiris.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username =etKullanici.getText().toString();
                String pass=etPassword.getText().toString();

                if("ahmet".equals(username)&& "1234".equals(pass))
                {
                    Intent i = new Intent(getApplicationContext(),sayfa2.class);
                }else{
                    Toast.makeText(getApplicationContext(),"hatalı giriş",Toast.LENGTH_LONG).show();
                }

                Intent i =new Intent(getApplicationContext(),sayfa2.class);
                startActivity(i);
            }
        });
    }
}
