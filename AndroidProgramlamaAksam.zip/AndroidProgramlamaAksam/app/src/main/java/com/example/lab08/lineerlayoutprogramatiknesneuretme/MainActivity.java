package com.example.lab08.lineerlayoutprogramatiknesneuretme;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
LinearLayout linearLayout;
Spinner spinner;
String[] urunler={"Cep Telefonu","Tablet","Masaüstü Bilgisayar","Dizüstü Biilgisayar","tv"};
ArrayAdapter<String> adapter;

public void nesneEkle (String metin)
{
    //pragmatik nsne üretimi
    TextView tvw =new TextView(getApplicationContext());
    tvw.setText(metin);
    linearLayout.addView(tvw);
}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner=findViewById(R.id.spinner);
        linearLayout=findViewById(R.id.LinearLayout);
        adapter= new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_spinner_item,urunler);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
              //  Toast.makeText(getApplicationContext(),urunler[position],Toast.LENGTH_LONG).show();
                nesneEkle(urunler[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


    }
}

//base adapter
//array adapter
//recyc
