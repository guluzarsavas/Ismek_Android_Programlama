package com.example.lab08.sharedpreference_loginornegi;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText etKullanici, etSifre;
    Button btnGiris;
    CheckBox BeniHatirla;
    SharedPreferences sp;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        editor = sp.edit();
        etKullanici = findViewById(R.id.etKullanici);
        etSifre = findViewById(R.id.etSifre);
        btnGiris = findViewById(R.id.btnGiris);
        BeniHatirla = findViewById(R.id.BeniHatirla);


        if (sp.getInt("BeniHatirla", 0) == 0)//checkbox seçilmemiş ise
        {
            etSifre.setText("");
            etKullanici.setText("");
            BeniHatirla.setChecked(false);

        } else if (sp.getInt("BeniHatirla", 0) == 1)//checkbox seçilmiş ise
        {
            etSifre.setText(sp.getString("pass", ""));
            etKullanici.setText(sp.getString("username", ""));
            BeniHatirla.setChecked(true);
        }
        btnGiris.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etKullanici.getText().toString();
                String pass = etSifre.getText().toString();

                if (!"".equals(username) && !"".equals(pass)) {
                    //username ve password degerleri doluysa


                    if (BeniHatirla.isChecked()) {
                        editor.putString("username", username);
                        editor.putString("pass", pass);
                        editor.putInt("BeniHatirla", 1);
                        editor.commit();
                    } else {

                        editor.putString("username", "");
                        editor.putString("pass", "");
                        editor.putInt("BeniHatirla", 0);
                        editor.commit();
                    }
                    startActivity(new Intent(getApplicationContext(),Sayfa2Activity.class));
                } else {
                    //herhangi biri boşsa

                    Toast.makeText(getApplicationContext(), "Boş değer bırakılamaz", Toast.LENGTH_LONG).show();
                }
            }
        });


    }
}
