package com.example.lab08.sharedpreference_loginornegi;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class Sayfa2Activity extends AppCompatActivity {
  EditText et1,et2;
  SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sayfa2);

        et1=findViewById(R.id.et1);
        et2=findViewById(R.id.et2);
        sp= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        et1.setText(sp.getString("username",""));
        et2.setText(sp.getString("pass",""));
    }
}
