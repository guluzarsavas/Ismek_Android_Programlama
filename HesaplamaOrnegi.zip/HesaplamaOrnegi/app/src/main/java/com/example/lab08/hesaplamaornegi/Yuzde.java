package com.example.lab08.hesaplamaornegi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Yuzde extends AppCompatActivity {
  EditText etsayiA, etsayiB;
   TextView tvhesapsonuc;
  Button btnYuzdeHesap1, btnYuzdeHesap2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yuzde);
        etsayiA=findViewById(R.id.etsayiA);
        etsayiB=findViewById(R.id.etsayiB);
        btnYuzdeHesap1=findViewById(R.id.btnYuzdeHesap1);
        btnYuzdeHesap2=findViewById(R.id.btnYuzdeHesap2);
        tvhesapsonuc=findViewById(R.id.tvhesapsonuc);

        btnYuzdeHesap1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //a sayısının yüzde b si kaçtır
                double sayiA=Double.parseDouble(etsayiA.getText().toString());
                double sayiB=Double.parseDouble(etsayiB.getText().toString());
                double sonuc=sayiA/100*sayiB;
                tvhesapsonuc.setText("Sonuç:"+ sonuc);

            }
        });

        btnYuzdeHesap2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //A sayısı B sayısının yüzde kaçıdır?
                double sayiA=Double.parseDouble(etsayiA.getText().toString());
                double sayiB=Double.parseDouble(etsayiB.getText().toString());
                double sonuc=sayiB*100/sayiA;
                tvhesapsonuc.setText("Sonuç:"+ sonuc);
            }
        });

    }
}
