package com.example.lab08.hesaplamaornegi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
//hesaplama.net
public class MainActivity extends AppCompatActivity {
  Button btnAlanCevre, btnYuzde;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btnAlanCevre=findViewById(R.id.btnAlanCevre);
        btnYuzde=findViewById(R.id.btnYuzde);
        btnAlanCevre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,Yuzde.class));
            }
        });
        btnAlanCevre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,AlanCevreActivity.class));
            }
        });


    }

}
